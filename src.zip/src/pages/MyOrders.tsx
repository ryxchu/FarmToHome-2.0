/**
 * MyOrders.tsx — NEW PAGE
 *
 * FIXES / NEW FEATURES:
 * 1. Full tabbed order management (To Pay, To Ship, To Receive, Delivered, Cancelled, Returned)
 * 2. Real-time Firestore subscription for live order updates
 * 3. Cancel order with confirmation
 * 4. Confirm delivery button
 * 5. Empty state per tab
 * 6. Mobile-first responsive layout
 * 7. Loads from localStorage cache while fetching fresh data
 */

import React, { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Package, Truck, CheckCircle2, XCircle, RotateCcw, Clock, ShoppingBag,
  ChevronRight, ArrowLeft, AlertCircle, Loader2
} from 'lucide-react';
import { collection, query, where, onSnapshot, updateDoc, doc, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';

interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  unit: string;
  image?: string;
}

interface Order {
  id: string;
  buyerId: string;
  farmerId: string;
  farmerName?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  paymentMethod: string;
  paymentStatus: string;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled' | 'returned';
  createdAt: string;
  updatedAt?: string;
  cancellationReason?: string;
  deliveryAddress?: string;
}

type TabId = 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled' | 'returned';

const TABS: { id: TabId; label: string; icon: React.ReactNode; color: string }[] = [
  { id: 'pending', label: 'To Pay', icon: <Clock className="w-4 h-4" />, color: 'amber' },
  { id: 'confirmed', label: 'To Ship', icon: <Package className="w-4 h-4" />, color: 'blue' },
  { id: 'shipped', label: 'To Receive', icon: <Truck className="w-4 h-4" />, color: 'violet' },
  { id: 'delivered', label: 'Delivered', icon: <CheckCircle2 className="w-4 h-4" />, color: 'emerald' },
  { id: 'cancelled', label: 'Cancelled', icon: <XCircle className="w-4 h-4" />, color: 'rose' },
  { id: 'returned', label: 'Returned', icon: <RotateCcw className="w-4 h-4" />, color: 'slate' },
];

const STATUS_COLORS: Record<TabId, string> = {
  pending: 'bg-amber-50 text-amber-700 border-amber-200',
  confirmed: 'bg-blue-50 text-blue-700 border-blue-200',
  shipped: 'bg-violet-50 text-violet-700 border-violet-200',
  delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  cancelled: 'bg-rose-50 text-rose-700 border-rose-200',
  returned: 'bg-slate-100 text-slate-600 border-slate-200',
};

const STATUS_LABELS: Record<TabId, string> = {
  pending: 'Awaiting Payment',
  confirmed: 'Confirmed – Preparing to Ship',
  shipped: 'Out for Delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
  returned: 'Return Requested',
};

interface MyOrdersProps {
  onBack?: () => void;
}

export const MyOrders: React.FC<MyOrdersProps> = ({ onBack }) => {
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<TabId>('pending');
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [cancelConfirm, setCancelConfirm] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Real-time order subscription
  useEffect(() => {
    if (!user?.uid) {
      setLoading(false);
      return;
    }

    // Load cached orders immediately for fast UX
    const cacheKey = `buyer_orders_${user.uid}`;
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      try {
        setOrders(JSON.parse(cached));
        setLoading(false);
      } catch {
        localStorage.removeItem(cacheKey);
      }
    }

    const q = query(
      collection(db, 'orders'),
      where('buyerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const ords: Order[] = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Order));
        setOrders(ords);
        localStorage.setItem(cacheKey, JSON.stringify(ords));
        setLoading(false);
        setError(null);
      },
      (err) => {
        console.error('[MyOrders] Firestore error:', err);
        setError('Unable to load orders. Showing cached data.');
        setLoading(false);
      }
    );

    return () => unsub();
  }, [user?.uid]);

  const filteredOrders = orders.filter((o) => o.status === activeTab);

  const handleCancelOrder = useCallback(async (orderId: string) => {
    setActionLoading(orderId);
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: 'cancelled',
        updatedAt: new Date().toISOString(),
        cancellationReason: 'Cancelled by buyer',
      });
      setCancelConfirm(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
    } finally {
      setActionLoading(null);
    }
  }, []);

  const handleConfirmDelivery = useCallback(async (orderId: string) => {
    setActionLoading(orderId);
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: 'delivered',
        updatedAt: new Date().toISOString(),
        paymentStatus: 'paid',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
    } finally {
      setActionLoading(null);
    }
  }, []);

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString('en-PH', {
        month: 'short', day: 'numeric', year: 'numeric',
      });
    } catch {
      return iso;
    }
  };

  const tabCounts = TABS.reduce((acc, tab) => {
    acc[tab.id] = orders.filter((o) => o.status === tab.id).length;
    return acc;
  }, {} as Record<TabId, number>);

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 px-4 py-4 sticky top-0 z-20 shadow-sm">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors shrink-0"
              aria-label="Go back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="text-lg font-black text-slate-900 tracking-tight">My Orders</h1>
            <p className="text-xs text-slate-500 font-medium">{orders.length} total orders</p>
          </div>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="bg-white border-b border-slate-100 sticky top-[65px] z-10">
        <div className="max-w-3xl mx-auto">
          <div className="flex overflow-x-auto no-scrollbar">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-4 py-3.5 text-[10px] sm:text-xs font-bold uppercase tracking-wider whitespace-nowrap border-b-2 transition-all relative shrink-0 ${
                  activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                {tab.icon}
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.label.split(' ')[0]}</span>
                {tabCounts[tab.id] > 0 && (
                  <span className="absolute -top-0.5 right-1 w-4 h-4 bg-primary text-white text-[8px] font-black rounded-full flex items-center justify-center">
                    {tabCounts[tab.id] > 9 ? '9+' : tabCounts[tab.id]}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-4 pt-6">
        {error && (
          <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-700 text-xs font-medium mb-4">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="text-sm text-slate-500 font-medium">Loading your orders...</p>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {filteredOrders.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-24 gap-4 text-center">
                  <div className="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center">
                    <ShoppingBag className="w-9 h-9 text-slate-300" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-700 text-base">No {TABS.find(t => t.id === activeTab)?.label} orders</p>
                    <p className="text-xs text-slate-400 font-medium mt-1">
                      {activeTab === 'pending'
                        ? 'Browse the marketplace and place your first order!'
                        : 'Orders in this status will appear here.'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredOrders.map((order) => (
                    <motion.div
                      key={order.id}
                      layout
                      className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden"
                    >
                      {/* Order Header */}
                      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-50">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                            {formatDate(order.createdAt)}
                          </span>
                        </div>
                        <span className={`px-2.5 py-1 text-[9px] font-black uppercase tracking-wider rounded-full border ${STATUS_COLORS[order.status as TabId]}`}>
                          {STATUS_LABELS[order.status as TabId] || order.status}
                        </span>
                      </div>

                      {/* Items */}
                      <div className="px-4 py-3 space-y-3">
                        {order.items?.map((item, idx) => (
                          <div key={`${item.id}-${idx}`} className="flex items-center gap-3">
                            <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-100 shrink-0 border border-slate-100">
                              {item.image ? (
                                <img src={item.image} alt={item.name} className="w-full h-full object-cover" loading="lazy" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <Package className="w-5 h-5 text-slate-300" />
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-slate-800 truncate">{item.name}</p>
                              <p className="text-xs text-slate-500 font-medium">
                                {item.quantity} {item.unit} × ₱{item.price}
                              </p>
                            </div>
                            <p className="text-sm font-bold text-primary shrink-0">
                              ₱{(item.quantity * item.price).toLocaleString()}
                            </p>
                          </div>
                        ))}
                      </div>

                      {/* Order Footer */}
                      <div className="px-4 py-3 bg-slate-50/50 border-t border-slate-100">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-slate-500 font-medium">Subtotal</span>
                          <span className="text-xs font-bold text-slate-700">₱{order.subtotal?.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs text-slate-500 font-medium">Delivery Fee</span>
                          <span className="text-xs font-bold text-slate-700">₱{order.deliveryFee?.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-black text-slate-800">Total Paid</span>
                          <span className="text-base font-black text-primary">₱{order.total?.toLocaleString()}</span>
                        </div>

                        {/* Payment Method */}
                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                            {order.paymentMethod === 'cash_on_delivery' ? 'Cash on Delivery' : order.paymentMethod}
                          </span>
                          {order.farmerName && (
                            <span className="text-[10px] font-bold text-slate-400">
                              by {order.farmerName}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      {(order.status === 'pending' || order.status === 'shipped') && (
                        <div className="px-4 py-3 flex items-center gap-2 border-t border-slate-100">
                          {order.status === 'pending' && (
                            <>
                              {cancelConfirm === order.id ? (
                                <>
                                  <p className="text-xs text-rose-600 font-medium flex-1">Cancel this order?</p>
                                  <button
                                    onClick={() => setCancelConfirm(null)}
                                    className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors"
                                  >
                                    No
                                  </button>
                                  <button
                                    onClick={() => handleCancelOrder(order.id)}
                                    disabled={actionLoading === order.id}
                                    className="px-4 py-2 text-xs font-bold text-white bg-rose-500 rounded-xl hover:bg-rose-600 transition-colors disabled:opacity-60 flex items-center gap-1.5"
                                  >
                                    {actionLoading === order.id && <Loader2 className="w-3 h-3 animate-spin" />}
                                    Yes, Cancel
                                  </button>
                                </>
                              ) : (
                                <button
                                  onClick={() => setCancelConfirm(order.id)}
                                  className="w-full min-h-[40px] py-2 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-200 rounded-xl hover:bg-rose-100 transition-colors active:scale-95 flex items-center justify-center gap-1.5"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  Cancel Order
                                </button>
                              )}
                            </>
                          )}

                          {order.status === 'shipped' && (
                            <button
                              onClick={() => handleConfirmDelivery(order.id)}
                              disabled={actionLoading === order.id}
                              className="w-full min-h-[44px] py-3 text-xs font-bold text-white bg-primary rounded-xl hover:bg-primary/90 transition-colors active:scale-95 flex items-center justify-center gap-2 shadow-sm disabled:opacity-60"
                            >
                              {actionLoading === order.id ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <CheckCircle2 className="w-4 h-4" />
                              )}
                              Order Received – Confirm Delivery
                            </button>
                          )}
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        )}
      </div>
    </div>
  );
};

export default MyOrders;